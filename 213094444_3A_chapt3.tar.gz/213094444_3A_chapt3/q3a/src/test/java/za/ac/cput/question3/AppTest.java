package za.ac.cput.question3;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.Before;
import za.ac.cput.q3a.FirstThreeNames;

import java.util.*;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    List<String> names ;
    Set<FirstThreeNames> objcts ;
    Map trackdown ;
    Person a ;
    FirstThreeNames person1 = new FirstThreeNames("Abel","Sacrificateur","Ngaliema");
    FirstThreeNames person2 = new FirstThreeNames("Kevin","Elie","Ngaliema");
    FirstThreeNames person3 = new FirstThreeNames("Tresor","Makaba","Ngaliema");

    @Before
    public void setUp()
    {
        a.setMap(person1);
        a.setNames(person1);
        a.setObjcts(person1,person1,person3 );
    }
    @org.junit.Test
    public void testName()
    {
        assertEquals("Abel" ,a.returnNames().get(0));
    }
    @org.junit.Test
    public void testSecondName()
    {
        assertEquals("Sacrificateur" ,a.returnNames().get(1));
    }
    @org.junit.Test
    public void testSurname()
    {
        assertEquals("Ngaliema" ,a.returnNames().get(2));
    }
    @org.junit.Test
    public void testObject()
    {
        assertEquals(person1, a.returnObjects().contains(person1));
    }
    @org.junit.Test
    public void testMap()
    {
        assertEquals("Abel",a.returnMap().containsKey(person1));
    }
    //the like can be done for the rest of the objects.
    //

}
