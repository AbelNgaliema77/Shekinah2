package za.ac.cput.question3;

import za.ac.cput.q3a.FirstThreeNames;

import java.util.*;

/**
 * Hello world!
 *
 */
public class Person
{
    FirstThreeNames person1 = new FirstThreeNames("Abel","Sacrificateur","Ngaliema");
    FirstThreeNames person2 = new FirstThreeNames("Kevin","Elie","Ngaliema");
    FirstThreeNames person3 = new FirstThreeNames("Tresor","Makaba","Ngaliema");

    List<String> names = new ArrayList<String>();
    Set <FirstThreeNames> objcts = new HashSet<FirstThreeNames>();
    Map  trackdown = new HashMap();

    public void setNames(FirstThreeNames person1)
    {
        names.add(person1.getName());
        names.add(person1.getSecond_name());
        names.add(person1.getLast_name());
    }
    public List<String> returnNames()
    {
        return names;
    }
    public void setObjcts( FirstThreeNames person1, FirstThreeNames person2, FirstThreeNames person3)
    {
        objcts.add(person1);
        objcts.add(person2);
        objcts.add(person3);

    }
    public Set<FirstThreeNames> returnObjects()
    {
        return objcts;
    }
    public void setMap(FirstThreeNames person1)
    {
        trackdown.put(person1 ,person1.getName());
        trackdown.put(person2,person2.getName());
        trackdown.put(person3,person3.getName());
    }
    public Map returnMap()
{
  return  trackdown;
}
}