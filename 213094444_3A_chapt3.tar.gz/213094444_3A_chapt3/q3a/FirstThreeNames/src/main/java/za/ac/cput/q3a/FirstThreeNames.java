package za.ac.cput.q3a;

/**
 * Created by student on 2015/02/20.
 */
public class FirstThreeNames {


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name;

    public String getSecond_name() {
        return second_name;
    }

    public void setSecond_name(String second_name) {
        this.second_name = second_name;
    }

    private String second_name;

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    private String last_name ;

    public FirstThreeNames(String name, String second_name, String last_name) {
        this.name = name;
        this.second_name = second_name;
        this.last_name = last_name;
    }

    public FirstThreeNames() {
    }
}
