package za.ac.cput.q3a;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.Before;

import static org.junit.Assert.assertEquals;

/**
 * Unit test for simple App.
 */
public class AppTest

{
    FirstThreeNames obj1;

    @Before
    public void setUp() {
        obj1 = new FirstThreeNames("Abel", "Sacrificateur", "Ngaliema");
    }

    @org.junit.Test
    public void testName() {
        assertEquals("Abel", obj1.getName());
    }

    @org.junit.Test
    public void testSecondName()
    {
        assertEquals("Sacrificateur",obj1.getSecond_name());
    }
    @org.junit.Test
    public void testSurname()
    {
        assertEquals("Ngaliema",obj1.getLast_name());
    }


}
