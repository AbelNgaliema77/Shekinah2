package za.ac.cput.q3b;

/**
 * Hello world!
 *
 */
public interface  Person
{
  public void setName(String n);
    public void setSurname(String sn);


}
