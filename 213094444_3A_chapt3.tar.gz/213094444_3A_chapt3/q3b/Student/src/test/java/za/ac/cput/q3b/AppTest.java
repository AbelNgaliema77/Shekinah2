package za.ac.cput.q3b;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.Before;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    Student std;
    @Before
    public void setUp()
    {
        std = new Student("Abel",213094444,"Ngaliema");
    }

    @org.junit.Test
    public void testName()
    {
        assertEquals("Abel",std.getName());
    }
    @org.junit.Test
    public void testSurname()
    {
        assertEquals("Ngaliema", std.getSurname());
    }
    @org.junit.Test
    public void testNumber()
    {
        assertEquals(213094444,std.getStudent());
    }
}
