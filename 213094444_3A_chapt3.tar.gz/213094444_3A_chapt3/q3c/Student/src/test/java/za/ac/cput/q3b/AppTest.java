package za.ac.cput.q3b;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.Before;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import za.ac.cput.q3b.Config.AppConfig;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    Person std;
    @Before
    public void setUp()
    {
        ApplicationContext ctx = new AnnotationConfigApplicationContext(AppConfig.class);
        std = (Person) ctx.getBean("person");
        std.setName("Abel");
        std.setSurname("Ngaliema");
    }

    @org.junit.Test
    public void testName()
    {
        assertEquals("Abel",std.getName());
    }
    @org.junit.Test
    public void testSurname()
    {
        assertEquals("Ngaliema", std.getSurname());
    }

}
