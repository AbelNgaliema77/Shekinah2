package za.ac.cput.q3b;

/**
 * Created by student on 2015/02/20.
 */
public class Student implements Person
{
    public Student() {
    }

    public Student(String name, int student, String surname) {
        this.name = name;
        this.student = student;
        this.surname = surname;
    }

    public String getSurname() {
        return surname;
    }

    public String getName() {
        return name;
    }

    String name, surname;

    public int getStudent() {
        return student;
    }

    public void setStudent(int student) {
        this.student = student;
    }

    int student;
    @Override
    public void setName(String n) {
        this.name = n;
    }

    @Override
    public void setSurname(String sn) {
        this.surname = sn;

    }

}
