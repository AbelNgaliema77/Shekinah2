package za.ac.cput.q3b.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import za.ac.cput.q3b.Person;
import za.ac.cput.q3b.Student;

/**
 * Created by student on 2015/02/20.
 */
@Configuration
public class AppConfig {


        @Bean(name="person")
        public Person getService() {
            return new Student();
        }



}
