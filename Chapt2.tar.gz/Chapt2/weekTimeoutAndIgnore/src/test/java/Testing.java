import org.junit.Before;
import org.junit.Ignore;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.Timeout;

/**
 * Created by student on 2015/02/13.
 */
public class Testing {

    String name;
    int age;
    float salary;
    boolean present;
    boolean sick;
   Testing objTemp;
    Testing obj1;
    Testing obj2;

    int [] anArray = new int [3];
    @Before

    public void setUpObj1()
    {
        obj1.name = "Abel";
        obj1.age = 20 ;
        obj1.salary = 12000.00f;
        obj1.present = true;
        obj1.sick = false;
    }
    public void setUpObj2()
    {
        obj2.name = "Abel";
        obj2.age = 20 ;
        obj2.salary = 12000.00f;
        obj2.present = true;
        obj2.sick = false;
    }





    @Rule
     public Timeout timeout = new Timeout(10000);

    @Test
    public void setTimeout() //timeout
    {
        while(true);
    }
    @Ignore //(expected = NullPointerException.class) //Disabling test
    public void testNullPointer()
    {
        NullPointerException npe = null;
        try
        {
            int a = objTemp.age;
        }
        catch(NullPointerException e)
        {
            npe = e;
        }
    }

}
