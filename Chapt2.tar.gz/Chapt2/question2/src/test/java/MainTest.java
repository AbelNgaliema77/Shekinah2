import junit.framework.TestCase;
import za.ac.cput.question2.Main;

/**
 * Created by student on 2015/02/13.
 */
public class MainTest extends TestCase {

    Main obj1 ;

    public void testName()
    {
        assertEquals(obj1.getName(),"Abel");
    }
    public void testInt()
    {
        assertEquals(obj1.getyr(),1995);
    }

}
