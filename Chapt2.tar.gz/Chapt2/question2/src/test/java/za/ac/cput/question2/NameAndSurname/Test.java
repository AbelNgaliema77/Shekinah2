package za.ac.cput.question2.NameAndSurname;

import junit.framework.TestCase;

/**
 * Created by student on 2015/02/13.
 */
public class Test extends TestCase {
    NameAndSurname obj1 = new NameAndSurname("Abel","Ngaliema");

    public void testName() //will fail
    {
        assertEquals(obj1.getName(),"Anel");
    }
    public void testSurname()
    {
        assertEquals(obj1.getSurname(),"Ngaliema");
    }
}
