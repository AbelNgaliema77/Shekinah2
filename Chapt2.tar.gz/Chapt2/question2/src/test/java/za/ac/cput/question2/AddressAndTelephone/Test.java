package za.ac.cput.question2.AddressAndTelephone;

import junit.framework.TestCase;

public class Test extends TestCase
{
    AddressAndTelephone obj1 = new AddressAndTelephone(0122222,7764);
    public void testTel()
    {
        assertEquals(obj1.getTel(),0122222);
    }
    public void testAddress()
    {
        assertEquals(obj1.getTel(),7764);
    }
}
