package za.ac.cput.question2.DateOfBirth;

import junit.framework.TestCase;

/**
 * Created by student on 2015/02/13.
 */
public class Test extends TestCase {
    DateOfBirth obj1 = new DateOfBirth(1995,9,1);

    public void testYear()
    {
        assertEquals(obj1.getYear(),1995);
    }
    public void testMonth()
    {
        assertEquals(obj1.getMonth(),9);
    }
    public void testDay()
    {
        assertEquals(obj1.getDay(),1);
    }
}
