package za.ac.cput.question2.DateOfBirth;

/**
 * Created by student on 2015/02/13.
 */
public class DateOfBirth {


        private int year, month,day;

        public DateOfBirth()
        {

        }

        public DateOfBirth(int yr, int mth, int d)
        {


            year = yr;
            month = mth;
            day = d;


        }
        public void setYear(int yr)
        {
            year = yr;
        }
        public void setMonth(int mth)
        {
            month = mth;
        }
        public void setDay(int d)
        {
            day = d;
        }
        public int getYear()
        {
            return year;
        }
        public int getMonth()
        {
            return month;
        }
        public int getDay()
        {
            return day;
        }


}
