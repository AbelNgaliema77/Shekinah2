package za.ac.cput.question2.Academics;

/**
 * Created by student on 2015/02/13.
 */
public class Academics {
    int level ;
    int [] finalYearMarks = new int [5];
    public Academics()
    {

    }
    public Academics(int l, int a,int b,int c, int d,int e )
    {
        level = l;
        finalYearMarks [0] = a;
        finalYearMarks [1] = b;
        finalYearMarks [2] = c;
        finalYearMarks [3] = d;
        finalYearMarks [4] = e;
    }
    public void setLevel(int g)
    {
        level = g;
    }
    public void setFinalYearMarks(int a,int b,int c, int d,int e)
    {
        finalYearMarks [0] = a;
        finalYearMarks [1] = b;
        finalYearMarks [2] = c;
        finalYearMarks [3] = d;
        finalYearMarks [4] = e;
    }
    public int [] getFinalYearMarks()
    {
        return finalYearMarks;
    }
    public int getLevel()
    {
        return  level;
    }
}
