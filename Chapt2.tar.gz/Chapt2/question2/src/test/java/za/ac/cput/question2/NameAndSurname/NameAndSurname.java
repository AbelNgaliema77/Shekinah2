package za.ac.cput.question2.NameAndSurname;

/**
 * Created by student on 2015/02/13.
 */
public class NameAndSurname
{

        private String name, surname;
        NameAndSurname()
        {

        }
        public NameAndSurname(String n, String sn)
        {
            name = n;
            surname = sn;
        }
        public void setName(String n)
        {
            name = n;
        }
        public void setSurname(String sn)
        {
            surname = sn;
        }
        public String getName()
        {
            return name;
        }
        public String getSurname()
        {
            return surname;
        }
    }


