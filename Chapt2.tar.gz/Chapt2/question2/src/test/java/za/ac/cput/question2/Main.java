package za.ac.cput.question2;
import org.junit.Before;
import za.ac.cput.question2.*;
import za.ac.cput.question2.Academics.Academics;
import za.ac.cput.question2.AddressAndTelephone.AddressAndTelephone;
import za.ac.cput.question2.DateOfBirth.DateOfBirth;
import za.ac.cput.question2.NameAndSurname.NameAndSurname;

/**
 * Created by student on 2015/02/13.
 */
public class Main {

    String name,surname;
    int  year, month,day, tel, adress,level;
    int [] finalMarks = new int [5];





      public static void main(String args []) {
          NameAndSurname obj1 = new NameAndSurname("Abel","Ngaliema");
          DateOfBirth obj2 = new DateOfBirth(1995,9,1);
          AddressAndTelephone obj3 = new AddressAndTelephone(0753,7764);
          Academics obj4 = new Academics(3,80,80,80,75,85);

          float mark;
          String message;

          int finalMark = 0 ;

          Main student1 = new Main();


              student1.name = obj1.getName();
              student1.surname = obj1.getSurname();
              student1.year = obj2.getYear();
              student1.month = obj2.getMonth();
              student1.day = obj2.getDay();
              student1.tel = obj3.getTel();
              student1.adress = obj3.getAdd();
              student1.level = obj4.getLevel();
              student1.finalMarks = obj4.getFinalYearMarks();

            for (int a = 0 ; a < 5 ; a++) {
                 finalMark = finalMark + student1.finalMarks[a];

             }

           mark = finalMark/5;
          if (mark<50.0)
          {
              message = "Student failed";
          }
          else if (mark>50.0 && mark<75.0)
          {
              message = "Student passed";
          }

          else
          {
              message = "Student passed with distinction";

          }

          System.out.println(student1.name+' '+ student1.surname+'\n'+student1.year+'/'+student1.month+'/'+student1.day+'\n'+student1.tel+' '+student1.adress+'\n'+finalMark+message);


      }
    public String getName()
    {
        return name;
    }
    public String getSurname()
    {
        return surname;
    }
    public int getyr()
    {
        return year;

    }
    public int getMonth()
    {
        return month;

    }
    public int getDay()
    {
        return year;

    }
    public void setName(String n)
    {
        name = n;
    }
    public void setTel(int n)
    {
        tel =n;
    }


}
