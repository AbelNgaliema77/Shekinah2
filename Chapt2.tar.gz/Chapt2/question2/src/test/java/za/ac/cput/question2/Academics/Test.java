package za.ac.cput.question2.Academics;

import junit.framework.TestCase;

/**
 * Created by student on 2015/02/13.
 */
public class Test extends TestCase {
    Academics obj1 = new Academics(3, 70, 80, 80, 80, 75);
    //Academics obj2 = new Academics(3,70,80,80,80,75);

    public void testLevel() {
        assertEquals(obj1.getLevel(), 3);
    }

    public void testGrades() {
        assertEquals(obj1.getFinalYearMarks(), obj1.getFinalYearMarks());
    }
}
