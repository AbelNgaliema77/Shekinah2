package za.ac.cput.question2.AddressAndTelephone;

/**
 * Created by student on 2015/02/13.
 */
public class AddressAndTelephone {

        private int tel, adress;

        public AddressAndTelephone(int tel, int adress)
        {
            this.tel = tel;
            this.adress = adress;
        }
        public int getTel()
        {
            return tel;
        }
        public int getAdd()
        {
            return this.adress;
        }

}
