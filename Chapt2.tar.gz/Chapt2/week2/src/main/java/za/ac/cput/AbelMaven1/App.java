package za.ac.cput.AbelMaven1;

/**
 * Hello world!
 *
 */
public class App 
{
  private String name;
    private int age;
    private float salary;
    private boolean present;
    private boolean sick;
    private App objTemp;
    private int [] numbers = new int [3];

    App()
    {

    }
   App(String n, int a, float salry, boolean prsnt, boolean sck,int a1,int a2,int a3)
    {
        name = n;
        age = a;
        salary = salry;
        present = prsnt;
        sick = sck;
        numbers[0] = 1 ;
        numbers[1] = 2;
        numbers[2] =3;


    }
    public String returnName()
    {
        return name ;


    }
    public int returnAge()
    {
       return age ;

    }
    public float returnSalary()
    {
       return salary;

    }
    public boolean returnPresent()
    {
       return present ;

    }
    public boolean returnSick()
    {
        return sick ;
    }
    public Exception returnException()
    {
        NullPointerException npe = null;
        try
        {
           int a = objTemp.returnAge();
        }
        catch(NullPointerException e)
        {
            npe = e;
        }
        return npe;
    }
    public int [] returnArray()
    {
        return numbers;
    }
}
