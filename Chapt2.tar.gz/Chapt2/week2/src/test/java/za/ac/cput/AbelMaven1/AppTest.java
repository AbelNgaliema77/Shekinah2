package za.ac.cput.AbelMaven1;

import junit.framework.Assert;
import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase {


    App obj1 = new App("Abel", 20, 12000.00f, true, false,1,2,3);
    App obj2 = null;
    App obj3 = new App("Abel", 20, 12000.00f, true, false,1,2,3);


    public void testName() {
        assertEquals(obj1.returnName(), "Abel");
    }

    public void testAge() {
        assertEquals(obj1.returnAge(), 20);
    }

    public void testSalary() {
        assertEquals(obj1.returnSalary(), 12000.00f);
    }

    public void testPresent() {
        assertTrue("is it true", obj1.returnPresent());
    }

    public void testSick() {
        assertFalse("is it false", obj1.returnSick());
    }

    public void testNull() {
        assertNull(obj2);
    }

    public void testNotNull() {
        assertNotNull(obj1);
    }

    public void testException()
    {
        NullPointerException e = null;
        try {
            int a = obj2.returnAge();
        } catch (NullPointerException a) {
            e = a;
        }
        assertEquals(obj1.returnException(), e);
    }

    public void testObjectEquality() {


        assertSame(obj1.returnName(), obj3.returnName());
    }

    public void testObjectIdentity() {
        assertNotSame(obj1,obj3);

    }
    public void testArrayContent()
    {
        assertEquals(obj1.returnArray(), obj1.returnArray());
    }
    public void testFail()
    {
        if (obj1 == null)
        {
            fail("Failed");
        }
    }

}
