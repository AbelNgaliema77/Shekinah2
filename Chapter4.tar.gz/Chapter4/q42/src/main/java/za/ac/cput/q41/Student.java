package za.ac.cput.q41;

/**
 * Created by student on 2015/02/27.
 */
public class Student implements Person{


    public void setName(String name) {
        this.name = name;
    }

    private String name;

    public void setSurname(String surname) {
        this.surname = surname;
    }

    private String surname;

    public Student(String n,String sn)
    {
        name = n;
        surname = sn;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSurname() {
       return surname;

    }



}
