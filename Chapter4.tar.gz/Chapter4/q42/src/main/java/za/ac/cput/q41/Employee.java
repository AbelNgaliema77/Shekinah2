package za.ac.cput.q41;

import java.lang.annotation.Inherited;

/**
 * Created by student on 2015/02/27.
 */
public class Employee extends Student implements  Person {



    private String name;
    Student s1;

    private String surname;
    private String employeeID;


    public void setName(String n)
    {
        super.setName(n);
    }
    public void setSurname(String sn)
    {
       super.setSurname(sn);
    }

    public Employee(String n,String sn)
    {
        super(n,sn);


        name = n;
        surname = sn;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public String getSurname() {
        return surname;
    }

    public void setEmployeeID (String i)
    {
        this.employeeID = i;
    }
}
