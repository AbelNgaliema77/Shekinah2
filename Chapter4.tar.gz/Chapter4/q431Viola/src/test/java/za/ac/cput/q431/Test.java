package za.ac.cput.q431;

import junit.framework.TestCase;
import org.junit.Before;

/**
 * Created by student on 2015/02/27.
 */
public class Test  extends TestCase{

    SetNames a;
    SetAgeAndNumber b;

    @Before
    public void setUp()
    {
        a = new SetNames("Ngaliema","Abel");
        b = new SetAgeAndNumber(77,20);
    }
    @org.junit.Test
    public void testName()
    {
        assertEquals("Abel", a.getName());
    }
    @org.junit.Test
    public void testSurname()
    {
        assertEquals("Ngaliema", a.getSurname());
    }
    @org.junit.Test

    public void testAge()
    {
        assertEquals(20,b.getAge());
    }
    @org.junit.Test
    public void testNumber()
    {
        assertEquals(77,b.getNumber());
    }

}
