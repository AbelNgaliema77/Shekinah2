package za.ac.cput.q431;

/**
 * Created by student on 2015/02/27.
 */
public class SetAgeAndNumber {


     int age, number ;
    public SetAgeAndNumber(int number, int age) {
        this.number = number;
        this.age = age;
    }

    public SetAgeAndNumber() {
    }

    public int getAge() {
        return age;
    }



    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setAge(int age) {
        this.age = age;
    }


}
