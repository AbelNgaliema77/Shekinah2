package za.ac.cput.q431;

/**
 * Created by student on 2015/02/27.
 */
public class SetNames {

    public SetNames(String surname, String name) {
        this.surname = surname;
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setSurname(String surname) {
        this.surname = surname;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name;

    public String getSurname() {
        return surname;
    }

    private String surname ;
}
