package za.ac.cput.q41;

import junit.framework.Test;
import junit.framework.TestCase;
import junit.framework.TestSuite;
import org.junit.Before;

/**
 * Unit test for simple App.
 */
public class AppTest 
    extends TestCase
{
    Person p1 ;

    @Before
    public void setUp()
    {
        p1 = new Employee("Abel","Ngaliema");

    }
    @org.junit.Test
    public void testName()
    {


        assertEquals("Abel",p1.getName());
    }
    @org.junit.Test
    public void testSurname()
    {


        assertEquals("Ngaliema",p1.getSurname());
        
    }


}
