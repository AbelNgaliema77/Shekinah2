package za.ac.cput.q41;

/**
 * Created by student on 2015/02/27.
 */
public interface Person {



    public String getName();
    public String getSurname();



}
